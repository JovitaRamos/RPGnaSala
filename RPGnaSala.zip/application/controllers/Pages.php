<?php
/**
 * Created by PhpStorm.
 * User: fgtor
 * Date: 15/08/2018
 * Time: 04:43
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {

    public function view($page = 'home')
    {
    }
}