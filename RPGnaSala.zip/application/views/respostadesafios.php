
<div class="col-lg-6">
    <div class="login-form-1">
        <div class="card-header">
            <strong>Resposta</strong> Desafio
        </div>
        <div class="card-body card-block">
                <?php
                    echo $resposta;
                ?>
           </form>
        </div>
    </div>
</div>